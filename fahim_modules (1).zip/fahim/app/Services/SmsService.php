<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class SmsService
{
    /**
     * Send an SMS via the configured SMS API.
     * Swap the HTTP call below for your chosen provider (Twilio, Nexmo, BD SMS API, etc.)
     *
     * @param  string  $phone   E.164 format e.g. +8801XXXXXXXXX
     * @param  string  $message
     * @return bool    true if sent successfully
     */
    public function send(string $phone, string $message): bool
    {
        $provider = config('services.sms.provider', 'twilio');

        try {
            return match ($provider) {
                'twilio'  => $this->sendViaTwilio($phone, $message),
                'nexmo'   => $this->sendViaNexmo($phone, $message),
                'bdsms'   => $this->sendViaBdSms($phone, $message),
                default   => false,
            };
        } catch (\Throwable $e) {
            Log::error('SMS send failed', ['phone' => $phone, 'error' => $e->getMessage()]);
            return false;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Provider implementations
    // ─────────────────────────────────────────────────────────────────────────

    private function sendViaTwilio(string $phone, string $message): bool
    {
        $sid   = config('services.twilio.sid');
        $token = config('services.twilio.token');
        $from  = config('services.twilio.from');

        $response = Http::withBasicAuth($sid, $token)
            ->asForm()
            ->post("https://api.twilio.com/2010-04-01/Accounts/{$sid}/Messages.json", [
                'To'   => $phone,
                'From' => $from,
                'Body' => $message,
            ]);

        return $response->successful();
    }

    private function sendViaNexmo(string $phone, string $message): bool
    {
        $response = Http::post('https://rest.nexmo.com/sms/json', [
            'api_key'    => config('services.nexmo.key'),
            'api_secret' => config('services.nexmo.secret'),
            'to'         => ltrim($phone, '+'),
            'from'       => config('services.nexmo.from', 'CampusShare'),
            'text'       => $message,
        ]);

        $messages = $response->json('messages', []);
        return ($messages[0]['status'] ?? '99') === '0';
    }

    private function sendViaBdSms(string $phone, string $message): bool
    {
        // Example: BulkSMSBD or similar Bangladesh SMS gateway
        $response = Http::get('https://api.bulksmsbd.com/api/smsapi', [
            'api_key'    => config('services.bdsms.api_key'),
            'type'       => 'text',
            'number'     => $phone,
            'senderid'   => config('services.bdsms.sender_id', 'CampusShr'),
            'message'    => $message,
        ]);

        return $response->successful() && str_contains($response->body(), '1001');
    }
}
