<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BorrowRequest extends Model
{
    use HasFactory;

    protected $fillable = [
        'resource_id',
        'borrower_id',
        'pickup_date',
        'return_date',
        'message',
        'status',        // pending, approved, rejected, returned, overdue
        'sms_sent',
    ];

    protected $casts = [
        'pickup_date' => 'date',
        'return_date' => 'date',
        'sms_sent'    => 'boolean',
    ];

    // ── Relationships ─────────────────────────────────────────────────────────

    public function resource()
    {
        return $this->belongsTo(Resource::class);
    }

    public function borrower()
    {
        return $this->belongsTo(User::class, 'borrower_id');
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function isOverdue(): bool
    {
        return $this->status === 'approved'
            && $this->return_date
            && $this->return_date->isPast();
    }

    public function getStatusColorAttribute(): string
    {
        return match ($this->status) {
            'pending'  => 'yellow',
            'approved' => 'green',
            'rejected' => 'red',
            'returned' => 'blue',
            'overdue'  => 'orange',
            default    => 'gray',
        };
    }
}
