<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Resource extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'title',
        'description',
        'category',
        'condition',
        'availability_status', // available, borrowed, unavailable
        'is_free',             // true = free lending, false = exchange
        'available_from',
        'available_until',
        'photo_path',
        'latitude',
        'longitude',
        'pickup_address',
        'recommendation_score', // computed or manually set
    ];

    protected $casts = [
        'is_free'          => 'boolean',
        'available_from'   => 'date',
        'available_until'  => 'date',
        'latitude'         => 'float',
        'longitude'        => 'float',
    ];

    // ── Relationships ─────────────────────────────────────────────────────────

    public function owner()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function borrowRequests()
    {
        return $this->hasMany(BorrowRequest::class);
    }

    public function reviews()
    {
        return $this->hasMany(Review::class);
    }

    // ── Scopes ────────────────────────────────────────────────────────────────

    public function scopeAvailable($query)
    {
        return $query->where('availability_status', 'available');
    }

    public function scopeByCategory($query, $category)
    {
        return $category ? $query->where('category', $category) : $query;
    }

    public function scopeByCondition($query, $condition)
    {
        return $condition ? $query->where('condition', $condition) : $query;
    }

    public function scopeRecommendedFirst($query)
    {
        return $query->orderByDesc('recommendation_score');
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function getPhotoUrlAttribute(): string
    {
        return $this->photo_path
            ? asset('storage/' . $this->photo_path)
            : asset('images/placeholder.png');
    }

    public function isAvailable(): bool
    {
        return $this->availability_status === 'available';
    }
}
