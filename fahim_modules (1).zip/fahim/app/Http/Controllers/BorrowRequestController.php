<?php

namespace App\Http\Controllers;

use App\Models\BorrowRequest;
use App\Models\Resource;
use App\Services\SmsService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BorrowRequestController extends Controller
{
    public function __construct(private SmsService $sms) {}

    // ── MODULE 2.1 – Show the borrow request form ─────────────────────────────

    public function create(Resource $resource)
    {
        abort_if(!$resource->isAvailable(), 403, 'Resource is not currently available.');
        abort_if($resource->user_id === Auth::id(), 403, 'You cannot borrow your own resource.');

        return view('borrow.create', compact('resource'));
    }

    // ── MODULE 2.1 – Submit a borrow request + fire SMS to owner ─────────────

    public function store(Request $request, Resource $resource)
    {
        abort_if(!$resource->isAvailable(), 403, 'Resource is not available.');
        abort_if($resource->user_id === Auth::id(), 403, 'Cannot borrow your own resource.');

        $validated = $request->validate([
            'pickup_date' => ['required', 'date', 'after_or_equal:today'],
            'return_date' => ['required', 'date', 'after:pickup_date'],
            'message'     => ['nullable', 'string', 'max:500'],
        ]);

        $borrowRequest = BorrowRequest::create([
            'resource_id' => $resource->id,
            'borrower_id' => Auth::id(),
            'pickup_date' => $validated['pickup_date'],
            'return_date' => $validated['return_date'],
            'message'     => $validated['message'] ?? null,
            'status'      => 'pending',
        ]);

        // ── Send SMS notification to resource owner ───────────────────────────
        $owner = $resource->owner;
        if ($owner->phone) {
            $smsSent = $this->sms->send(
                $owner->phone,
                "Hi {$owner->name}, {$borrowRequest->borrower->name} has requested to borrow " .
                "your '{$resource->title}' from {$validated['pickup_date']} to {$validated['return_date']}. " .
                "Log in to CampusShare to respond."
            );

            $borrowRequest->update(['sms_sent' => $smsSent]);
        }

        return redirect()->route('borrow.map', $resource)
            ->with('success', 'Borrow request sent! The owner has been notified.');
    }

    // ── MODULE 2.3 – Map view showing pickup location ─────────────────────────

    public function map(Resource $resource)
    {
        $googleMapsKey = config('services.google_maps.key');
        return view('borrow.map', compact('resource', 'googleMapsKey'));
    }
}
