<?php

namespace App\Http\Controllers;

use App\Models\Resource;
use Illuminate\Http\Request;

class ResourceController extends Controller
{
    /**
     * MODULE 1 – Browse resources with filters.
     * Recommended resources are shown first (highest recommendation_score).
     */
    public function index(Request $request)
    {
        $query = Resource::with('owner')
            ->available()
            ->recommendedFirst();

        // ── Filters ───────────────────────────────────────────────────────────
        if ($request->filled('category')) {
            $query->byCategory($request->category);
        }

        if ($request->filled('condition')) {
            $query->byCondition($request->condition);
        }

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('title', 'like', "%{$search}%")
                  ->orWhere('description', 'like', "%{$search}%");
            });
        }

        if ($request->filled('type')) {
            $isFree = $request->type === 'free';
            $query->where('is_free', $isFree);
        }

        $resources = $query->paginate(12)->withQueryString();

        $categories = Resource::distinct()->pluck('category')->filter()->sort()->values();

        return view('resources.index', compact('resources', 'categories'));
    }

    /**
     * Show a single resource detail page.
     */
    public function show(Resource $resource)
    {
        $resource->load(['owner', 'reviews.reviewer']);
        return view('resources.show', compact('resource'));
    }
}
