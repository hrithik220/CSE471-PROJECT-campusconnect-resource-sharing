<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('resources', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('title');
            $table->text('description')->nullable();
            $table->string('category');           // textbook, notes, lab_equipment, electronics
            $table->string('condition');          // new, good, fair, poor
            $table->string('availability_status')->default('available'); // available, borrowed, unavailable
            $table->boolean('is_free')->default(true);  // true=free lending, false=exchange
            $table->date('available_from')->nullable();
            $table->date('available_until')->nullable();
            $table->string('photo_path')->nullable();
            $table->decimal('latitude', 10, 7)->nullable();
            $table->decimal('longitude', 10, 7)->nullable();
            $table->string('pickup_address')->nullable();
            $table->unsignedSmallInteger('recommendation_score')->default(0);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('resources');
    }
};
