<?php

/*
|--------------------------------------------------------------------------
| services.php  –  Add these keys to your existing services config
|--------------------------------------------------------------------------
| Copy the relevant blocks into your project's config/services.php
*/

return [

    // ── Existing Laravel services ─────────────────────────────────────────────
    'mailgun'  => [ 'domain' => env('MAILGUN_DOMAIN'), 'secret' => env('MAILGUN_SECRET'), 'endpoint' => env('MAILGUN_ENDPOINT', 'api.mailgun.net') ],
    'ses'      => [ 'key' => env('AWS_ACCESS_KEY_ID'), 'secret' => env('AWS_SECRET_ACCESS_KEY'), 'region' => env('AWS_DEFAULT_REGION', 'us-east-1') ],
    'postmark' => [ 'token' => env('POSTMARK_TOKEN') ],

    // ── Google Maps ───────────────────────────────────────────────────────────
    'google_maps' => [
        'key' => env('GOOGLE_MAPS_API_KEY'),
    ],

    // ── SMS Provider (choose one; set SMS_PROVIDER in .env) ───────────────────
    'sms' => [
        'provider' => env('SMS_PROVIDER', 'twilio'), // twilio | nexmo | bdsms
    ],

    'twilio' => [
        'sid'   => env('TWILIO_SID'),
        'token' => env('TWILIO_AUTH_TOKEN'),
        'from'  => env('TWILIO_FROM'),
    ],

    'nexmo' => [
        'key'    => env('NEXMO_KEY'),
        'secret' => env('NEXMO_SECRET'),
        'from'   => env('NEXMO_FROM', 'CampusShare'),
    ],

    'bdsms' => [
        'api_key'   => env('BDSMS_API_KEY'),
        'sender_id' => env('BDSMS_SENDER_ID', 'CampusShr'),
    ],

];
