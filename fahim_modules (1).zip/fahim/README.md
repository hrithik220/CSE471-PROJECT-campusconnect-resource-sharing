# CampusShare — Fahim's Modules (M1 & M2)

## Files Included

```
app/
  Http/Controllers/
    ResourceController.php      ← M1: Browse + filter resources
    BorrowRequestController.php ← M2: Send borrow request + SMS + map
  Models/
    Resource.php
    BorrowRequest.php
  Services/
    SmsService.php              ← Supports Twilio / Nexmo / BdSMS

database/migrations/
  ..._create_resources_table.php
  ..._create_borrow_requests_table.php

resources/views/
  resources/
    index.blade.php   ← M1: Browse page with filters & recommended-first grid
    show.blade.php    ← M1: Resource detail page
  borrow/
    create.blade.php  ← M2: Borrow request form
    map.blade.php     ← M2: Google Maps pickup location

routes/
  fahim_routes.php   ← All routes (add to web.php)

config/
  services.php       ← SMS + Google Maps config keys

.env.example         ← All required .env keys
```

---

## Setup Steps

### 1. Copy files into your Laravel project
Merge each directory into your existing Laravel project structure.

### 2. Register routes
In `routes/web.php`, add:
```php
require __DIR__.'/../routes/fahim_routes.php';
// OR just copy the routes directly into web.php
```

### 3. Run migrations
```bash
php artisan migrate
```

### 4. Set .env keys
Copy the relevant lines from `.env.example` into your `.env`:
- `GOOGLE_MAPS_API_KEY`
- `SMS_PROVIDER` + provider-specific keys

### 5. Register SmsService (optional binding)
In `AppServiceProvider::register()`:
```php
$this->app->singleton(\App\Services\SmsService::class);
```

### 6. Storage link (for photos)
```bash
php artisan storage:link
```

---

## Module 1 — Browse Resources
- **URL**: `GET /resources`
- Filters: `?category=textbook&condition=good&type=free&search=physics`
- Recommended resources (highest `recommendation_score`) appear first
- Paginated, 12 per page

## Module 2 — Borrow Request + SMS + Map
- **Borrow form**: `GET/POST /resources/{id}/borrow`
  - Validates pickup date ≥ today, return date > pickup date
  - Fires SMS to owner via configured provider
- **Map view**: `GET /resources/{id}/map`
  - Google Maps JS API with a marker at the resource's lat/lng
  - "Get Directions" link opens Google Maps navigation
