<?php

use App\Http\Controllers\ResourceController;
use App\Http\Controllers\BorrowRequestController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| FAHIM – Module 1 & 2 Routes
|--------------------------------------------------------------------------
*/

// ── MODULE 1: Browse & view resources (public) ────────────────────────────────
Route::get('/resources', [ResourceController::class, 'index'])->name('resources.index');
Route::get('/resources/{resource}', [ResourceController::class, 'show'])->name('resources.show');

// ── MODULE 2: Borrow requests & map (auth required) ───────────────────────────
Route::middleware('auth')->group(function () {
    // Send a borrow request
    Route::get('/resources/{resource}/borrow',  [BorrowRequestController::class, 'create'])->name('borrow.create');
    Route::post('/resources/{resource}/borrow', [BorrowRequestController::class, 'store'])->name('borrow.store');

    // Map view for pickup location
    Route::get('/resources/{resource}/map', [BorrowRequestController::class, 'map'])->name('borrow.map');
});
