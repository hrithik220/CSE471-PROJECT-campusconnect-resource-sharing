{{-- resources/views/borrow/create.blade.php --}}
{{-- MODULE 2: Borrow request form with proposed pickup date, return date, message --}}

@extends('layouts.app')

@section('title', 'Request to Borrow: ' . $resource->title)

@section('content')
<div class="min-h-screen bg-gray-50 py-8 px-4">
    <div class="max-w-lg mx-auto">

        <a href="{{ route('resources.show', $resource) }}"
           class="inline-flex items-center text-sm text-indigo-600 hover:underline mb-6">
            ← Back to resource
        </a>

        <div class="bg-white rounded-2xl shadow-sm overflow-hidden">

            {{-- Resource summary card --}}
            <div class="flex items-center gap-4 p-5 border-b bg-indigo-50">
                <img src="{{ $resource->photo_url }}" alt="{{ $resource->title }}"
                     class="w-16 h-16 rounded-xl object-cover"/>
                <div>
                    <h2 class="font-semibold text-gray-900">{{ $resource->title }}</h2>
                    <p class="text-sm text-gray-500 capitalize">{{ str_replace('_', ' ', $resource->category) }} · {{ ucfirst($resource->condition) }}</p>
                    <p class="text-xs mt-0.5 {{ $resource->is_free ? 'text-green-600' : 'text-amber-600' }} font-medium">
                        {{ $resource->is_free ? 'Free Lending' : 'Exchange' }}
                    </p>
                </div>
            </div>

            {{-- Form --}}
            <form method="POST" action="{{ route('borrow.store', $resource) }}" class="p-6 space-y-5">
                @csrf

                {{-- Success / error messages --}}
                @if(session('success'))
                    <div class="bg-green-50 text-green-700 text-sm px-4 py-3 rounded-lg">
                        {{ session('success') }}
                    </div>
                @endif

                @if($errors->any())
                    <div class="bg-red-50 text-red-700 text-sm px-4 py-3 rounded-lg space-y-1">
                        @foreach($errors->all() as $error)
                            <p>{{ $error }}</p>
                        @endforeach
                    </div>
                @endif

                <h3 class="text-lg font-semibold text-gray-900">Your Borrow Request</h3>

                {{-- Pickup date --}}
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1" for="pickup_date">
                        Proposed Pickup Date <span class="text-red-500">*</span>
                    </label>
                    <input type="date" id="pickup_date" name="pickup_date"
                           value="{{ old('pickup_date') }}"
                           min="{{ date('Y-m-d') }}"
                           class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400
                                  @error('pickup_date') border-red-400 @enderror"/>
                    @error('pickup_date')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

                {{-- Return date --}}
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1" for="return_date">
                        Proposed Return Date <span class="text-red-500">*</span>
                    </label>
                    <input type="date" id="return_date" name="return_date"
                           value="{{ old('return_date') }}"
                           min="{{ date('Y-m-d', strtotime('+1 day')) }}"
                           class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400
                                  @error('return_date') border-red-400 @enderror"/>
                    @error('return_date')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

                {{-- Message --}}
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1" for="message">
                        Message to Owner <span class="text-gray-400 text-xs">(optional)</span>
                    </label>
                    <textarea id="message" name="message" rows="3"
                              placeholder="E.g. I need this for my upcoming exam..."
                              maxlength="500"
                              class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-indigo-400
                                     @error('message') border-red-400 @enderror">{{ old('message') }}</textarea>
                    @error('message')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

                {{-- SMS notice --}}
                <p class="text-xs text-gray-400 bg-gray-50 rounded-lg px-4 py-3">
                    📱 The resource owner will be notified by SMS when you submit this request.
                </p>

                <button type="submit"
                        class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2.5 rounded-lg transition">
                    Send Borrow Request
                </button>
            </form>
        </div>

        {{-- Map preview link --}}
        @if($resource->latitude && $resource->longitude)
        <div class="mt-4 text-center">
            <a href="{{ route('borrow.map', $resource) }}"
               class="text-sm text-indigo-600 hover:underline">
                📍 View pickup location on map
            </a>
        </div>
        @endif

    </div>
</div>

{{-- Ensure return_date >= pickup_date + 1 dynamically --}}
<script>
    document.getElementById('pickup_date').addEventListener('change', function() {
        const pickupVal = this.value;
        if (pickupVal) {
            const next = new Date(pickupVal);
            next.setDate(next.getDate() + 1);
            document.getElementById('return_date').min = next.toISOString().split('T')[0];
        }
    });
</script>
@endsection
