{{-- resources/views/borrow/map.blade.php --}}
{{-- MODULE 2: Google Maps pickup location view --}}

@extends('layouts.app')

@section('title', 'Pickup Location – ' . $resource->title)

@push('head')
{{-- Google Maps JS API --}}
<script
    src="https://maps.googleapis.com/maps/api/js?key={{ $googleMapsKey }}&callback=initMap"
    async defer>
</script>
@endpush

@section('content')
<div class="min-h-screen bg-gray-50 py-8 px-4">
    <div class="max-w-4xl mx-auto">

        <a href="{{ route('resources.show', $resource) }}"
           class="inline-flex items-center text-sm text-indigo-600 hover:underline mb-6">
            ← Back to resource
        </a>

        @if(session('success'))
            <div class="bg-green-100 border border-green-300 text-green-800 text-sm px-4 py-3 rounded-lg mb-5 flex items-center gap-2">
                <span>✅</span> {{ session('success') }}
            </div>
        @endif

        <div class="bg-white rounded-2xl shadow-sm overflow-hidden">

            {{-- Header --}}
            <div class="p-5 border-b">
                <h1 class="text-xl font-bold text-gray-900">Pickup Location</h1>
                <p class="text-sm text-gray-500 mt-0.5">
                    Resource: <span class="font-medium text-gray-700">{{ $resource->title }}</span>
                    &nbsp;·&nbsp;Owner: {{ $resource->owner->name }}
                </p>
                @if($resource->pickup_address)
                    <p class="mt-2 text-sm text-indigo-700 font-medium">
                        📍 {{ $resource->pickup_address }}
                    </p>
                @endif
            </div>

            {{-- Map --}}
            @if($resource->latitude && $resource->longitude)
                <div id="map" class="w-full" style="height: 420px;"></div>

                {{-- Directions link --}}
                <div class="p-4 border-t text-sm text-gray-500 flex items-center justify-between">
                    <span>Coordinates: {{ $resource->latitude }}, {{ $resource->longitude }}</span>
                    <a href="https://www.google.com/maps/dir/?api=1&destination={{ $resource->latitude }},{{ $resource->longitude }}"
                       target="_blank"
                       class="inline-flex items-center gap-1 text-indigo-600 hover:underline font-medium">
                        Get Directions →
                    </a>
                </div>
            @else
                <div class="h-64 flex items-center justify-center text-gray-400 text-sm">
                    No map location available for this resource.
                </div>
            @endif
        </div>

        {{-- Nearby resources CTA --}}
        <div class="mt-6 text-center">
            <a href="{{ route('resources.index') }}"
               class="text-sm text-indigo-600 hover:underline">
                Browse more resources →
            </a>
        </div>
    </div>
</div>

@if($resource->latitude && $resource->longitude)
<script>
    function initMap() {
        const location = {
            lat: {{ $resource->latitude }},
            lng: {{ $resource->longitude }}
        };

        const map = new google.maps.Map(document.getElementById('map'), {
            center: location,
            zoom: 16,
            styles: [
                { featureType: 'poi', elementType: 'labels', stylers: [{ visibility: 'off' }] }
            ]
        });

        const marker = new google.maps.Marker({
            position: location,
            map,
            title: '{{ addslashes($resource->title) }}',
            animation: google.maps.Animation.DROP,
        });

        const infoWindow = new google.maps.InfoWindow({
            content: `
                <div style="max-width:200px; font-family: sans-serif;">
                    <p style="font-weight:600; margin:0 0 4px">{{ addslashes($resource->title) }}</p>
                    <p style="font-size:12px; color:#555; margin:0">{{ addslashes($resource->pickup_address ?? 'Campus Area') }}</p>
                    <p style="font-size:12px; color:#4f46e5; margin:6px 0 0">Owner: {{ addslashes($resource->owner->name) }}</p>
                </div>
            `
        });

        marker.addListener('click', () => infoWindow.open(map, marker));
        infoWindow.open(map, marker); // Open by default
    }
</script>
@endif
@endsection
