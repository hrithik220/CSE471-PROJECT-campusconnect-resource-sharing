{{-- resources/views/resources/show.blade.php --}}
{{-- MODULE 1: Single resource detail page --}}

@extends('layouts.app')

@section('title', $resource->title)

@section('content')
<div class="min-h-screen bg-gray-50 py-8 px-4">
    <div class="max-w-4xl mx-auto">

        {{-- Back link --}}
        <a href="{{ route('resources.index') }}"
           class="inline-flex items-center text-sm text-indigo-600 hover:underline mb-6">
            ← Back to resources
        </a>

        <div class="bg-white rounded-2xl shadow-sm overflow-hidden">
            <div class="md:flex">

                {{-- Photo --}}
                <div class="md:w-2/5 h-64 md:h-auto bg-gray-100 flex-shrink-0">
                    <img src="{{ $resource->photo_url }}"
                         alt="{{ $resource->title }}"
                         class="w-full h-full object-cover"/>
                </div>

                {{-- Details --}}
                <div class="p-6 flex-1 flex flex-col">
                    <div class="flex items-start justify-between gap-3 mb-3">
                        <h1 class="text-2xl font-bold text-gray-900">{{ $resource->title }}</h1>
                        <span class="shrink-0 text-sm font-semibold px-3 py-1 rounded-full
                            {{ $resource->is_free ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700' }}">
                            {{ $resource->is_free ? 'Free Lending' : 'Exchange' }}
                        </span>
                    </div>

                    <p class="text-gray-600 mb-4">{{ $resource->description }}</p>

                    {{-- Meta grid --}}
                    <dl class="grid grid-cols-2 gap-x-4 gap-y-2 text-sm mb-5">
                        <div>
                            <dt class="text-gray-400">Category</dt>
                            <dd class="font-medium text-gray-800 capitalize">{{ str_replace('_', ' ', $resource->category) }}</dd>
                        </div>
                        <div>
                            <dt class="text-gray-400">Condition</dt>
                            <dd class="font-medium text-gray-800 capitalize">{{ $resource->condition }}</dd>
                        </div>
                        <div>
                            <dt class="text-gray-400">Availability</dt>
                            <dd>
                                <span class="inline-block px-2 py-0.5 rounded-full text-xs font-semibold
                                    {{ $resource->availability_status === 'available' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' }}">
                                    {{ ucfirst($resource->availability_status) }}
                                </span>
                            </dd>
                        </div>
                        @if($resource->available_until)
                        <div>
                            <dt class="text-gray-400">Available Until</dt>
                            <dd class="font-medium text-gray-800">{{ $resource->available_until->format('d M Y') }}</dd>
                        </div>
                        @endif
                        @if($resource->pickup_address)
                        <div class="col-span-2">
                            <dt class="text-gray-400">Pickup Location</dt>
                            <dd class="font-medium text-gray-800">{{ $resource->pickup_address }}</dd>
                        </div>
                        @endif
                    </dl>

                    {{-- CTA --}}
                    @auth
                        @if($resource->user_id !== auth()->id() && $resource->isAvailable())
                            <a href="{{ route('borrow.create', $resource) }}"
                               class="mt-auto inline-block bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-6 py-2.5 rounded-lg text-center transition">
                                Request to Borrow
                            </a>
                        @elseif($resource->user_id === auth()->id())
                            <p class="text-sm text-gray-400 mt-auto">This is your resource.</p>
                        @else
                            <p class="text-sm text-gray-400 mt-auto">Currently not available.</p>
                        @endif
                    @else
                        <a href="{{ route('login') }}"
                           class="mt-auto inline-block bg-indigo-600 text-white font-semibold px-6 py-2.5 rounded-lg text-center hover:bg-indigo-700 transition">
                            Log in to Borrow
                        </a>
                    @endauth
                </div>
            </div>

            {{-- Owner info --}}
            <div class="border-t px-6 py-4 flex items-center gap-4">
                <div class="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold text-sm">
                    {{ strtoupper(substr($resource->owner->name, 0, 1)) }}
                </div>
                <div>
                    <p class="text-sm font-semibold text-gray-800">{{ $resource->owner->name }}</p>
                    <p class="text-xs text-gray-400">Resource Owner</p>
                </div>
            </div>
        </div>

        {{-- Reviews section --}}
        @if($resource->reviews->isNotEmpty())
        <div class="mt-8">
            <h2 class="text-lg font-semibold text-gray-800 mb-4">Reviews</h2>
            <div class="space-y-4">
                @foreach($resource->reviews as $review)
                <div class="bg-white rounded-xl shadow-sm p-4">
                    <div class="flex items-center gap-3 mb-1">
                        <span class="font-medium text-sm text-gray-800">{{ $review->reviewer->name }}</span>
                        <span class="text-yellow-400 text-xs">{{ str_repeat('★', $review->rating ?? 5) }}</span>
                    </div>
                    <p class="text-sm text-gray-600">{{ $review->comment }}</p>
                </div>
                @endforeach
            </div>
        </div>
        @endif

    </div>
</div>
@endsection
