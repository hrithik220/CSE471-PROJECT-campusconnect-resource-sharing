{{-- resources/views/resources/index.blade.php --}}
{{-- MODULE 1: Browse resources with filters. Recommended resources appear first. --}}

@extends('layouts.app')

@section('title', 'Browse Resources')

@section('content')
<div class="min-h-screen bg-gray-50">

    {{-- ── Hero / Search Bar ──────────────────────────────────────────────── --}}
    <div class="bg-indigo-700 text-white py-10 px-4">
        <div class="max-w-5xl mx-auto">
            <h1 class="text-3xl font-bold mb-1">Browse Campus Resources</h1>
            <p class="text-indigo-200 mb-6">Find textbooks, notes, lab equipment, and electronics shared by fellow students.</p>

            <form method="GET" action="{{ route('resources.index') }}" id="filterForm">
                {{-- Search --}}
                <div class="flex flex-col sm:flex-row gap-3">
                    <input
                        type="text"
                        name="search"
                        value="{{ request('search') }}"
                        placeholder="Search by title or description..."
                        class="flex-1 rounded-lg px-4 py-2.5 text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-300"
                    />
                    <button type="submit"
                        class="bg-white text-indigo-700 font-semibold px-6 py-2.5 rounded-lg hover:bg-indigo-50 transition">
                        Search
                    </button>
                </div>

                {{-- Filters row --}}
                <div class="flex flex-wrap gap-3 mt-4">
                    {{-- Category --}}
                    <select name="category" onchange="document.getElementById('filterForm').submit()"
                        class="rounded-lg px-3 py-2 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-300">
                        <option value="">All Categories</option>
                        @foreach($categories as $cat)
                            <option value="{{ $cat }}" @selected(request('category') === $cat)>
                                {{ ucfirst(str_replace('_', ' ', $cat)) }}
                            </option>
                        @endforeach
                    </select>

                    {{-- Condition --}}
                    <select name="condition" onchange="document.getElementById('filterForm').submit()"
                        class="rounded-lg px-3 py-2 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-300">
                        <option value="">Any Condition</option>
                        @foreach(['new','good','fair','poor'] as $cond)
                            <option value="{{ $cond }}" @selected(request('condition') === $cond)>
                                {{ ucfirst($cond) }}
                            </option>
                        @endforeach
                    </select>

                    {{-- Type --}}
                    <select name="type" onchange="document.getElementById('filterForm').submit()"
                        class="rounded-lg px-3 py-2 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-300">
                        <option value="">Free & Exchange</option>
                        <option value="free"     @selected(request('type') === 'free')>Free Lending</option>
                        <option value="exchange" @selected(request('type') === 'exchange')>Exchange Only</option>
                    </select>

                    {{-- Clear filters --}}
                    @if(request()->anyFilled(['search','category','condition','type']))
                        <a href="{{ route('resources.index') }}"
                           class="bg-white/20 hover:bg-white/30 text-white text-sm px-4 py-2 rounded-lg transition">
                            ✕ Clear Filters
                        </a>
                    @endif
                </div>
            </form>
        </div>
    </div>

    {{-- ── Resource Grid ───────────────────────────────────────────────────── --}}
    <div class="max-w-5xl mx-auto px-4 py-8">

        {{-- Results count --}}
        <div class="flex items-center justify-between mb-4">
            <p class="text-sm text-gray-500">
                Showing <span class="font-medium text-gray-700">{{ $resources->total() }}</span> resource(s)
                @if(request()->anyFilled(['search','category','condition','type']))
                    matching your filters
                @endif
                &nbsp;·&nbsp;
                <span class="text-indigo-600 font-medium">★ Recommended shown first</span>
            </p>
        </div>

        @if($resources->isEmpty())
            <div class="text-center py-20 text-gray-400">
                <svg class="mx-auto w-16 h-16 mb-4 opacity-40" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                          d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
                <p class="text-lg font-medium">No resources found</p>
                <p class="text-sm mt-1">Try adjusting your filters.</p>
            </div>
        @else
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                @foreach($resources as $resource)
                    <a href="{{ route('resources.show', $resource) }}"
                       class="bg-white rounded-2xl shadow-sm hover:shadow-md transition overflow-hidden flex flex-col group">

                        {{-- Photo --}}
                        <div class="relative h-44 bg-gray-100 overflow-hidden">
                            <img src="{{ $resource->photo_url }}"
                                 alt="{{ $resource->title }}"
                                 class="w-full h-full object-cover group-hover:scale-105 transition duration-300"/>

                            {{-- Recommended badge --}}
                            @if($resource->recommendation_score > 0)
                                <span class="absolute top-2 left-2 bg-indigo-600 text-white text-xs font-semibold px-2 py-0.5 rounded-full">
                                    ★ Recommended
                                </span>
                            @endif

                            {{-- Type badge --}}
                            <span class="absolute top-2 right-2 text-xs font-semibold px-2 py-0.5 rounded-full
                                {{ $resource->is_free ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700' }}">
                                {{ $resource->is_free ? 'Free' : 'Exchange' }}
                            </span>
                        </div>

                        {{-- Content --}}
                        <div class="p-4 flex flex-col flex-1">
                            <h3 class="font-semibold text-gray-900 text-base leading-snug mb-1 group-hover:text-indigo-600 transition">
                                {{ $resource->title }}
                            </h3>
                            <p class="text-gray-500 text-sm line-clamp-2 mb-3">
                                {{ $resource->description }}
                            </p>

                            <div class="mt-auto flex items-center justify-between text-xs text-gray-400">
                                <span class="capitalize">
                                    {{ str_replace('_', ' ', $resource->category) }}
                                    &nbsp;·&nbsp;
                                    {{ ucfirst($resource->condition) }}
                                </span>
                                <span class="text-gray-500 font-medium">{{ $resource->owner->name }}</span>
                            </div>
                        </div>
                    </a>
                @endforeach
            </div>

            {{-- Pagination --}}
            <div class="mt-8">
                {{ $resources->links() }}
            </div>
        @endif
    </div>
</div>
@endsection
